<?php
$title='Beranda';
require 'includes/header.php';
$berita=$pdo->query("SELECT * FROM berita ORDER BY tanggal DESC LIMIT 3")->fetchAll();
$guru=$pdo->query("SELECT * FROM guru ORDER BY nama LIMIT 4")->fetchAll();
$galeri=$pdo->query("SELECT * FROM galeri ORDER BY id DESC LIMIT 6")->fetchAll();
?>
<section class="hero">
  <div class="container hero-inner">
    <div><span class="eyebrow">Selamat Datang</span>
      <h1><?= htmlspecialchars($site['nama_sekolah']) ?></h1>
      <p><?= htmlspecialchars($site['tagline']) ?></p>
      <a class="btn" href="profil.php">Jelajahi Sekolah</a>
    </div>
    <div class="hero-card">📚<strong>Belajar • Berkarya • Berprestasi</strong><span>Menumbuhkan karakter dan kompetensi peserta didik.</span></div>
  </div>
</section>
<section class="section"><div class="container"><div class="section-head"><h2>Berita Terbaru</h2><a href="berita.php">Lihat semua →</a></div><div class="cards">
<?php foreach($berita as $b): ?><article class="card"><div class="thumb"><?= $b['gambar'] ? '<img src="uploads/'.htmlspecialchars($b['gambar']).'">' : '📰' ?></div><div class="pad"><small><?= date('d M Y',strtotime($b['tanggal'])) ?></small><h3><?= htmlspecialchars($b['judul']) ?></h3><p><?= htmlspecialchars(mb_substr(strip_tags($b['isi']),0,110)) ?>...</p><a href="detail-berita.php?id=<?=$b['id']?>">Baca selengkapnya</a></div></article><?php endforeach; ?>
</div></div></section>
<section class="section soft"><div class="container"><div class="section-head"><h2>Tenaga Pendidik</h2><a href="guru.php">Lihat semua →</a></div><div class="cards">
<?php foreach($guru as $g): ?><article class="person"><div class="avatar"><?= $g['foto'] ? '<img src="uploads/'.htmlspecialchars($g['foto']).'">' : '👩‍🏫' ?></div><h3><?= htmlspecialchars($g['nama']) ?></h3><p><?= htmlspecialchars($g['jabatan']) ?></p></article><?php endforeach; ?>
</div></div></section>
<section class="section"><div class="container"><div class="section-head"><h2>Galeri Kegiatan</h2><a href="galeri.php">Lihat semua →</a></div><div class="gallery"><?php foreach($galeri as $g): ?><div class="gallery-item"><?php if($g['gambar']): ?><img src="uploads/<?=htmlspecialchars($g['gambar'])?>"><?php else: ?>📷<?php endif; ?><span><?=htmlspecialchars($g['judul'])?></span></div><?php endforeach; ?></div></div></section>
<?php require 'includes/footer.php'; ?>