<?php
require '../includes/auth.php';
require '../config/database.php';

$uploadDir = dirname(__DIR__) . '/uploads/';
$uploadUrl = '../uploads/';
$allowedExt = ['jpg','jpeg','png','webp'];
$maxSize = 5 * 1024 * 1024;
$message = '';
$error = '';

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

function safeFileName($name) {
    $name = strtolower(pathinfo($name, PATHINFO_FILENAME));
    $name = preg_replace('/[^a-z0-9_-]/', '-', $name);
    return trim($name, '-') ?: 'foto-guru';
}

if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $s = $pdo->prepare('SELECT foto FROM guru WHERE id=?');
    $s->execute([$id]);
    $old = $s->fetch();
    if ($old) {
        $pdo->prepare('DELETE FROM guru WHERE id=?')->execute([$id]);
        if (!empty($old['foto']) && is_file($uploadDir . $old['foto'])) {
            unlink($uploadDir . $old['foto']);
        }
    }
    header('Location: guru.php?status=hapus');
    exit;
}

if (isset($_GET['status'])) {
    $message = match ($_GET['status']) {
        'simpan' => 'Data guru berhasil disimpan.',
        'update' => 'Data guru dan foto berhasil diperbarui.',
        'foto' => 'Foto guru berhasil diperbarui.',
        'hapus' => 'Data guru berhasil dihapus.',
        default => ''
    };
}

$edit = null;
if (isset($_GET['edit'])) {
    $s = $pdo->prepare('SELECT * FROM guru WHERE id=?');
    $s->execute([(int)$_GET['edit']]);
    $edit = $s->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $nama = trim($_POST['nama'] ?? '');
    $jabatan = trim($_POST['jabatan'] ?? '');
    $mapel = trim($_POST['mapel'] ?? '');
    $gantiFoto = isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE;
    $newFile = null;

    if ($nama === '' || $jabatan === '' || $mapel === '') {
        $error = 'Nama, jabatan, dan mata pelajaran wajib diisi.';
    }

    if (!$error && $gantiFoto) {
        if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
            $error = 'Foto gagal diunggah.';
        } elseif ($_FILES['foto']['size'] > $maxSize) {
            $error = 'Ukuran foto maksimal 5 MB.';
        } else {
            $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowedExt, true)) {
                $error = 'Format foto harus JPG, JPEG, PNG, atau WEBP.';
            } else {
                $check = @getimagesize($_FILES['foto']['tmp_name']);
                if ($check === false) {
                    $error = 'File yang diunggah bukan gambar yang valid.';
                } else {
                    $newFile = safeFileName($_FILES['foto']['name']) . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
                    if (!move_uploaded_file($_FILES['foto']['tmp_name'], $uploadDir . $newFile)) {
                        $error = 'Foto tidak dapat disimpan ke folder uploads.';
                    }
                }
            }
        }
    }

    if (!$error) {
        if ($id) {
            $s = $pdo->prepare('SELECT foto FROM guru WHERE id=?');
            $s->execute([$id]);
            $old = $s->fetch();
            if (!$old) {
                $error = 'Data guru tidak ditemukan.';
            } else {
                if ($newFile) {
                    $pdo->prepare('UPDATE guru SET nama=?, jabatan=?, mapel=?, foto=? WHERE id=?')
                        ->execute([$nama, $jabatan, $mapel, $newFile, $id]);
                    if (!empty($old['foto']) && is_file($uploadDir . $old['foto'])) {
                        unlink($uploadDir . $old['foto']);
                    }
                    header('Location: guru.php?status=update');
                } else {
                    $pdo->prepare('UPDATE guru SET nama=?, jabatan=?, mapel=? WHERE id=?')
                        ->execute([$nama, $jabatan, $mapel, $id]);
                    header('Location: guru.php?status=simpan');
                }
                exit;
            }
        } else {
            $pdo->prepare('INSERT INTO guru (nama, jabatan, mapel, foto) VALUES (?, ?, ?, ?)')
                ->execute([$nama, $jabatan, $mapel, $newFile]);
            header('Location: guru.php?status=simpan');
            exit;
        }
    }
}

$rows = $pdo->query('SELECT * FROM guru ORDER BY nama ASC')->fetchAll();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kelola Guru</title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.teacher-photo-preview{width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid #e7ecf2;background:#edf3f8}
.teacher-photo-empty{width:90px;height:90px;border-radius:50%;background:#edf3f8;display:grid;place-items:center;font-size:38px}
.photo-field{grid-column:1/-1;background:#f8fafc;border:1px dashed #cfd8e3;padding:18px;border-radius:12px}
.photo-current{display:flex;align-items:center;gap:15px;margin-bottom:12px}
.teacher-table-photo{width:58px;height:58px;border-radius:50%;object-fit:cover;background:#edf3f8}
.photo-help{font-size:13px;color:#667085;display:block;margin-top:-8px;margin-bottom:12px}
.success{background:#e8f7ee;color:#176b3a;padding:11px 14px;border-radius:9px;margin-bottom:18px}
.error{background:#fee4e2;color:#9b1c1c;padding:11px 14px;border-radius:9px;margin-bottom:18px}
</style>
</head>
<body>
<div class="admin-layout">
<aside>
<h2>🎓 Admin</h2>
<a href="dashboard.php">Dashboard</a>
<a href="berita.php">Berita</a>
<a class="active" href="guru.php">Guru</a>
<a href="galeri.php">Galeri</a>
<a href="agenda.php">Agenda</a>
<a href="kegiatan.php">Kegiatan</a>
<a href="../index.php">Website</a>
<a href="logout.php">Keluar</a>
</aside>

<section class="admin-main">
<h1>Kelola Guru & Tenaga Kependidikan</h1>
<p>Tambahkan data guru dan ubah foto profil guru melalui halaman ini.</p>

<?php if ($message): ?><div class="success"><?=htmlspecialchars($message)?></div><?php endif; ?>
<?php if ($error): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?>

<form class="admin-card form-grid" method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?=$edit['id']??0?>">

<label>Nama
<input type="text" name="nama" value="<?=htmlspecialchars($edit['nama']??'')?>" required>
</label>

<label>Jabatan
<input type="text" name="jabatan" value="<?=htmlspecialchars($edit['jabatan']??'')?>" required>
</label>

<label>Mata Pelajaran / Kelas
<input type="text" name="mapel" value="<?=htmlspecialchars($edit['mapel']??'')?>" required>
</label>

<div class="photo-field">
<label>Foto Guru</label>
<?php if ($edit && !empty($edit['foto'])): ?>
<div class="photo-current">
<img class="teacher-photo-preview" src="<?=$uploadUrl.htmlspecialchars($edit['foto'])?>" alt="Foto guru">
<div>
<strong>Foto saat ini</strong><br>
<span class="photo-help">Pilih foto baru jika ingin mengganti foto.</span>
</div>
</div>
<?php endif; ?>
<input type="file" name="foto" accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp" <?=$edit?'':'required'?>>
<span class="photo-help">Format: JPG, JPEG, PNG, WEBP. Maksimal 5 MB.</span>
</div>

<button class="btn"><?= $edit?'💾 Simpan Perubahan':'➕ Tambah Guru' ?></button>
<?php if ($edit): ?><a class="btn" style="background:#6b7280" href="guru.php">Batal</a><?php endif; ?>
</form>

<div class="admin-card table-wrap">
<table>
<tr><th>Foto</th><th>Nama</th><th>Jabatan</th><th>Mata Pelajaran / Kelas</th><th>Aksi</th></tr>
<?php foreach($rows as $r): ?>
<tr>
<td>
<?php if (!empty($r['foto'])): ?>
<img class="teacher-table-photo" src="<?=$uploadUrl.htmlspecialchars($r['foto'])?>" alt="<?=htmlspecialchars($r['nama'])?>">
<?php else: ?>
<div class="teacher-photo-empty">👩‍🏫</div>
<?php endif; ?>
</td>
<td><?=htmlspecialchars($r['nama'])?></td>
<td><?=htmlspecialchars($r['jabatan'])?></td>
<td><?=htmlspecialchars($r['mapel'])?></td>
<td>
<a href="?edit=<?=$r['id']?>">✏️ Edit / Ganti Foto</a> ·
<a onclick="return confirm('Hapus data guru dan foto ini?')" href="?hapus=<?=$r['id']?>">🗑️ Hapus</a>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>
</section>
</div>
</body>
</html>
