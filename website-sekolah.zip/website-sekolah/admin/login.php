<?php
require '../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!empty($_SESSION['admin_login'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['admin_login'] = true;
            $_SESSION['admin_id'] = $user['id'] ?? null;
            $_SESSION['admin_username'] = $user['username'];
            $_SESSION['admin_name'] = $user['nama'];

            header('Location: dashboard.php');
            exit;
        }

        $error = 'Username atau password salah.';
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login Admin - Website Sekolah</title>
<style>
*{box-sizing:border-box}
body{
    margin:0;
    min-height:100vh;
    font-family:Arial,Helvetica,sans-serif;
    background:linear-gradient(135deg,#0d6efd,#174ea6);
    display:flex;
    align-items:center;
    justify-content:center;
    padding:20px;
}
.login-wrapper{width:100%;max-width:430px}
.login-card{
    background:#fff;
    border-radius:20px;
    padding:35px;
    box-shadow:0 20px 55px rgba(0,0,0,.2);
}
.logo{
    width:76px;height:76px;
    margin:0 auto 16px;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#eef5ff;
    font-size:38px;
}
h1{text-align:center;margin:0 0 7px;font-size:26px;color:#172033}
.subtitle{text-align:center;color:#667085;margin:0 0 28px}
.form-group{margin-bottom:18px}
label{display:block;font-weight:700;margin-bottom:7px;color:#344054}
.input-wrap{position:relative}
input{
    width:100%;
    height:48px;
    border:1px solid #d0d5dd;
    border-radius:10px;
    padding:0 44px 0 14px;
    font-size:15px;
    outline:none;
}
input:focus{
    border-color:#0d6efd;
    box-shadow:0 0 0 3px rgba(13,110,253,.12);
}
.toggle{
    position:absolute;
    right:8px;top:7px;
    width:34px;height:34px;
    border:0;background:transparent;
    cursor:pointer;font-size:18px;
}
.login-btn{
    width:100%;
    height:48px;
    border:0;
    border-radius:10px;
    background:#0d6efd;
    color:#fff;
    font-size:16px;
    font-weight:700;
    cursor:pointer;
}
.login-btn:hover{background:#0b5ed7}
.alert{
    background:#fff0f0;
    color:#b42318;
    border:1px solid #fecdca;
    padding:11px 13px;
    border-radius:9px;
    margin-bottom:18px;
}
.back{
    display:block;
    text-align:center;
    margin-top:20px;
    color:#0d6efd;
    text-decoration:none;
    font-size:14px;
}
.demo{
    margin-top:18px;
    padding:12px;
    border-radius:9px;
    background:#f8f9fa;
    font-size:13px;
    color:#667085;
}
.demo strong{color:#344054}
@media(max-width:480px){
    .login-card{padding:28px 20px}
}
</style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">
        <div class="logo">🎓</div>

        <h1>Login Admin</h1>
        <p class="subtitle">Panel Administrasi Website Sekolah</p>

        <?php if ($error): ?>
            <div class="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="on">
            <div class="form-group">
                <label for="username">Username</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Masukkan username"
                    value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    autocomplete="username"
                    required
                    autofocus
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrap">
                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Masukkan password"
                        autocomplete="current-password"
                        required
                    >
                    <button type="button" class="toggle" onclick="togglePassword()" aria-label="Tampilkan password">👁️</button>
                </div>
            </div>

            <button type="submit" class="login-btn">Masuk sebagai Admin</button>
        </form>

        <a class="back" href="../index.php">← Kembali ke Website</a>

        <div class="demo">
            <strong>Akun admin default:</strong><br>
            Username: admin<br>
            Password: password
        </div>
    </div>
</div>

<script>
function togglePassword(){
    const input=document.getElementById('password');
    const button=document.querySelector('.toggle');
    if(input.type==='password'){
        input.type='text';
        button.textContent='🙈';
    }else{
        input.type='password';
        button.textContent='👁️';
    }
}
</script>

</body>
</html>
