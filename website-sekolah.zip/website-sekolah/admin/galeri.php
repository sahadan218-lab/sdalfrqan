<?php
require '../includes/auth.php';
require '../config/database.php';

$uploadDir = __DIR__ . '/../uploads/';
$maxSize = 5 * 1024 * 1024;
$allowed = ['jpg', 'jpeg', 'png', 'webp'];
$message = '';
$error = '';

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

function safeImageName($original, $ext) {
    $base = pathinfo($original, PATHINFO_FILENAME);
    $base = strtolower($base);
    $base = preg_replace('/[^a-z0-9_-]+/', '-', $base);
    $base = trim($base, '-_');
    if ($base === '') $base = 'galeri';
    return $base . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
}

function uploadImage($file, $uploadDir, $allowed, $maxSize) {
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return [null, 'Foto wajib dipilih.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [null, 'Upload foto gagal.'];
    }
    if ($file['size'] > $maxSize) {
        return [null, 'Ukuran foto maksimal 5 MB.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        return [null, 'Format foto harus JPG, JPEG, PNG, atau WEBP.'];
    }

    // Pastikan file benar-benar merupakan gambar.
    if (@getimagesize($file['tmp_name']) === false) {
        return [null, 'File yang dipilih bukan gambar yang valid.'];
    }

    $name = safeImageName($file['name'], $ext);
    if (!move_uploaded_file($file['tmp_name'], $uploadDir . $name)) {
        return [null, 'Foto tidak dapat disimpan ke folder uploads.'];
    }

    return [$name, null];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'tambah') {
        $judul = trim($_POST['judul'] ?? '');

        if ($judul === '') {
            $error = 'Judul foto wajib diisi.';
        } else {
            [$filename, $uploadError] = uploadImage($_FILES['gambar'] ?? null, $uploadDir, $allowed, $maxSize);

            if ($uploadError) {
                $error = $uploadError;
            } else {
                $stmt = $pdo->prepare("INSERT INTO galeri (judul, gambar) VALUES (?, ?)");
                $stmt->execute([$judul, $filename]);
                $message = 'Foto berhasil ditambahkan.';
            }
        }
    }

    if ($action === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        $judul = trim($_POST['judul'] ?? '');

        $stmt = $pdo->prepare("SELECT * FROM galeri WHERE id = ?");
        $stmt->execute([$id]);
        $old = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$old) {
            $error = 'Data galeri tidak ditemukan.';
        } elseif ($judul === '') {
            $error = 'Judul foto wajib diisi.';
        } else {
            $filename = $old['gambar'];
            $newFilename = null;

            if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] !== UPLOAD_ERR_NO_FILE) {
                [$newFilename, $uploadError] = uploadImage($_FILES['gambar'], $uploadDir, $allowed, $maxSize);
                if ($uploadError) {
                    $error = $uploadError;
                } else {
                    $filename = $newFilename;
                }
            }

            if (!$error) {
                $stmt = $pdo->prepare("UPDATE galeri SET judul = ?, gambar = ? WHERE id = ?");
                $stmt->execute([$judul, $filename, $id]);

                if ($newFilename && !empty($old['gambar'])) {
                    $oldPath = $uploadDir . basename($old['gambar']);
                    if (is_file($oldPath)) @unlink($oldPath);
                }
                $message = 'Foto berhasil diperbarui.';
            }
        }
    }

    if ($action === 'hapus') {
        $id = (int)($_POST['id'] ?? 0);

        $stmt = $pdo->prepare("SELECT gambar FROM galeri WHERE id = ?");
        $stmt->execute([$id]);
        $old = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($old) {
            $stmt = $pdo->prepare("DELETE FROM galeri WHERE id = ?");
            $stmt->execute([$id]);

            if (!empty($old['gambar'])) {
                $path = $uploadDir . basename($old['gambar']);
                if (is_file($path)) @unlink($path);
            }

            $message = 'Foto berhasil dihapus.';
        }
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM galeri WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch(PDO::FETCH_ASSOC);
}

$rows = $pdo->query("SELECT * FROM galeri ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kelola Galeri</title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.admin-gallery-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:25px}
.admin-gallery-card{background:#fff;border:1px solid #e5e9ef;border-radius:14px;overflow:hidden}
.admin-gallery-card img{width:100%;height:190px;object-fit:cover}
.admin-gallery-body{padding:15px}
.admin-gallery-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.btn-danger{background:#dc3545;color:#fff!important}
.btn-secondary{background:#667085;color:#fff!important}
.current-photo{width:140px;height:100px;object-fit:cover;border-radius:9px;margin:8px 0 12px}
.notice-success{background:#e7f7ed;color:#176b3a;padding:11px;border-radius:8px;margin-bottom:18px}
@media(max-width:900px){.admin-gallery-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:560px){.admin-gallery-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="admin-layout">
<aside>
<h2>🎓 Admin</h2>
<a href="dashboard.php">Dashboard</a>
<a href="berita.php">Berita</a>
<a href="guru.php">Guru</a>
<a class="active" href="galeri.php">Galeri</a>
<a href="agenda.php">Agenda</a>
<a href="kegiatan.php">Kegiatan</a>
<a href="../index.php">Website</a>
<a href="logout.php">Keluar</a>
</aside>

<section class="admin-main">
<h1>Kelola Galeri</h1>

<?php if ($message): ?><div class="notice-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="admin-card">
<h2><?= $edit ? 'Edit Foto Galeri' : 'Tambah Foto Galeri' ?></h2>
<form class="form-grid" method="post" enctype="multipart/form-data">
<input type="hidden" name="action" value="<?= $edit ? 'edit' : 'tambah' ?>">
<?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>

<label>Judul Foto
<input type="text" name="judul" required value="<?= htmlspecialchars($edit['judul'] ?? '') ?>">
</label>

<label>Foto <?= $edit ? '<small>(kosongkan jika tidak diganti)</small>' : '' ?>
<?php if ($edit && !empty($edit['gambar'])): ?>
<img class="current-photo" src="../uploads/<?= htmlspecialchars($edit['gambar']) ?>" alt="">
<?php endif; ?>
<input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp" <?= $edit ? '' : 'required' ?>>
<small>JPG, JPEG, PNG, WEBP — maksimal 5 MB.</small>
</label>

<button class="btn" type="submit"><?= $edit ? 'Simpan Perubahan' : 'Upload Foto' ?></button>
<?php if ($edit): ?><a class="btn btn-secondary" href="galeri.php">Batal</a><?php endif; ?>
</form>
</div>

<div class="admin-gallery-grid">
<?php if ($rows): ?>
<?php foreach ($rows as $r): ?>
<article class="admin-gallery-card">
<img src="../uploads/<?= htmlspecialchars($r['gambar']) ?>" alt="<?= htmlspecialchars($r['judul']) ?>">
<div class="admin-gallery-body">
<strong><?= htmlspecialchars($r['judul']) ?></strong>
<div class="admin-gallery-actions">
<a class="btn btn-secondary" href="?edit=<?= (int)$r['id'] ?>">Edit</a>
<form method="post" onsubmit="return confirm('Yakin ingin menghapus foto ini?');">
<input type="hidden" name="action" value="hapus">
<input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
<button class="btn btn-danger" type="submit">Hapus</button>
</form>
</div>
</div>
</article>
<?php endforeach; ?>
<?php else: ?>
<div class="admin-card">Belum ada foto galeri.</div>
<?php endif; ?>
</div>
</section>
</div>
</body>
</html>
