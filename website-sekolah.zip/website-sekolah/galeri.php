<?php
$title = 'Galeri';
require 'includes/header.php';

$rows = $pdo->query("SELECT * FROM galeri ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<section class="page-banner">
    <div class="container">
        <h1>Galeri Sekolah</h1>
        <p>Dokumentasi kegiatan sekolah</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if ($rows): ?>
            <div class="gallery">
                <?php foreach ($rows as $g): ?>
                    <article class="gallery-item">
                        <button
                            type="button"
                            class="gallery-open"
                            data-image="uploads/<?= htmlspecialchars($g['gambar'], ENT_QUOTES, 'UTF-8') ?>"
                            data-title="<?= htmlspecialchars($g['judul'], ENT_QUOTES, 'UTF-8') ?>"
                            aria-label="Lihat <?= htmlspecialchars($g['judul'], ENT_QUOTES, 'UTF-8') ?>"
                        >
                            <img
                                src="uploads/<?= htmlspecialchars($g['gambar'], ENT_QUOTES, 'UTF-8') ?>"
                                alt="<?= htmlspecialchars($g['judul'], ENT_QUOTES, 'UTF-8') ?>"
                                loading="lazy"
                                onerror="this.style.display='none'; this.parentElement.classList.add('gallery-no-image');"
                            >
                            <span class="gallery-zoom">🔍</span>
                        </button>
                        <div class="gallery-caption">
                            <?= htmlspecialchars($g['judul'], ENT_QUOTES, 'UTF-8') ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="admin-card gallery-empty">
                <div>📷</div>
                <h3>Belum ada foto galeri</h3>
                <p>Foto kegiatan sekolah yang diunggah oleh admin akan tampil di halaman ini.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<div class="gallery-modal" id="galleryModal" aria-hidden="true">
    <button type="button" class="gallery-modal-close" id="galleryClose" aria-label="Tutup">&times;</button>
    <div class="gallery-modal-box">
        <img id="galleryModalImage" src="" alt="">
        <h3 id="galleryModalTitle"></h3>
    </div>
</div>

<style>
.gallery-open{display:block;width:100%;height:100%;padding:0;border:0;background:transparent;cursor:zoom-in;position:relative}
.gallery-open img{width:100%;height:100%;object-fit:cover}
.gallery-zoom{position:absolute;right:12px;top:12px;width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:rgba(0,0,0,.65);font-size:18px}
.gallery-caption{position:absolute;bottom:0;left:0;right:0;background:rgba(0,0,0,.62);color:#fff;padding:10px 12px;font-size:14px;z-index:2}
.gallery-no-image{display:flex!important;align-items:center;justify-content:center;background:#edf3f8}
.gallery-empty{text-align:center;padding:50px 20px}
.gallery-empty div{font-size:48px}
.gallery-modal{display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.88);align-items:center;justify-content:center;padding:25px}
.gallery-modal.show{display:flex}
.gallery-modal-box{width:min(950px,95vw);max-height:90vh;background:#fff;border-radius:16px;overflow:hidden}
.gallery-modal-box img{width:100%;max-height:78vh;object-fit:contain;background:#111;display:block}
.gallery-modal-box h3{margin:0;padding:14px 18px}
.gallery-modal-close{position:fixed;right:18px;top:15px;width:44px;height:44px;border:0;border-radius:50%;background:#fff;color:#111;font-size:30px;cursor:pointer;z-index:10000}
</style>

<script>
(function () {
    const modal = document.getElementById('galleryModal');
    const image = document.getElementById('galleryModalImage');
    const title = document.getElementById('galleryModalTitle');
    const close = document.getElementById('galleryClose');

    document.querySelectorAll('.gallery-open').forEach(function (button) {
        button.addEventListener('click', function () {
            image.src = this.dataset.image;
            image.alt = this.dataset.title;
            title.textContent = this.dataset.title;
            modal.classList.add('show');
            modal.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
        });
    });

    function closeModal() {
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
        image.src = '';
        document.body.style.overflow = '';
    }

    close.addEventListener('click', closeModal);
    modal.addEventListener('click', function (e) {
        if (e.target === modal) closeModal();
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeModal();
    });
})();
</script>

<?php require 'includes/footer.php'; ?>
