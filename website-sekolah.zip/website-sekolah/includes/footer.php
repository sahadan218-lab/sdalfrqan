</main>
<footer class="footer">
  <div class="container footer-grid">
    <div><h3><?= htmlspecialchars($site['nama_sekolah'] ?? 'Sekolah Kita') ?></h3><p><?= htmlspecialchars($site['alamat'] ?? '') ?></p></div>
    <div><h3>Kontak</h3><strong>📞 0778-0000000</strong><br><strong>📧 sdalfurqan_adm@yahoo.com</strong></p></div>
  </div>
  <div class="copyright">© <?= date('Y') ?> <?= htmlspecialchars($site['nama_sekolah'] ?? 'Sekolah Kita') ?>. Semua hak dilindungi.</div>
</footer>
<script src="assets/js/script.js"></script>
</body></html>