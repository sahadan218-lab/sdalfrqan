<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/database.php';
$site = $pdo->query("SELECT * FROM pengaturan LIMIT 1")->fetch();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($title ?? ($site['nama_sekolah'] ?? 'Website Sekolah')) ?></title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="topbar">
  <div class="container nav">
    <a class="brand" href="index.php">
      <span class="brand-logo">🏫</span>
      <span><?= htmlspecialchars($site['nama_sekolah'] ?? 'Sekolah Kita') ?></span>
    </a>
    <button class="menu-toggle" onclick="document.querySelector('.nav-links').classList.toggle('show')">☰</button>
    <nav class="nav-links">
      <a href="index.php">Beranda</a>
      <a href="profil.php">Profil</a>
      <a href="guru.php">Guru</a>
      <a href="berita.php">Berita</a>
      <a href="kegiatan.php">Kegiatan</a>
      <a href="galeri.php">Galeri</a>
      <a href="agenda.php">Agenda</a>
      <a href="kontak.php">Kontak</a>
    </nav>
  </div>
</header>
<main>