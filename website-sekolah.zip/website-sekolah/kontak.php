<?php $title='Kontak'; require 'includes/header.php'; ?>
<section class="page-banner"><div class="container"><h1>Kontak Sekolah</h1></div></section>
<section class="section"><div class="container contact-grid"><div><h2>Hubungi Kami</h2><div class="contact-info">

                <div class="contact-item">
                    <strong>🏫 Alamat</strong>
                    Jl. Kartini III No 60 Sungai Harapan, Sekupang Batam.
                </div>

                <div class="contact-item">
                    <strong>📞 Telepon</strong>
                    <a href="tel:0778123456">
                        (0778) 123456
                    </a>
                </div>

                <div class="contact-item">
                    <strong>📱 WhatsApp</strong>
                    <a href="https://wa.me/6281234567890"
                       target="_blank">
                        0812-3456-7890
                    </a>
                </div>

                <div class="contact-item">
                    <strong>📧 Email</strong>
                    <a href="mailto:info@sekolah.sch.id">
                        sdalfurqan_adm@yahoo.com
                    </a>
                </div>

                <div class="contact-item">
                    <strong>🕐 Jam Pelayanan</strong>
                    Senin - Jumat<br>
                    07.00 - 15.00 WIB
                </div>

            </div>

        </div>
<div class="mapbox">📍<br>Lokasi Sekolah</div></div></section>
<?php require 'includes/footer.php'; ?>