WEBSITE SEKOLAH - VERSI GALERI DIPERBAIKI

Perbaikan galeri:
- Kompatibel dengan tabel galeri asli: id, judul, gambar, created_at.
- Tidak membutuhkan kolom kategori/keterangan tambahan.
- Halaman publik galeri memiliki popup/lightbox.
- Admin dapat tambah, edit, ganti foto, dan hapus foto.
- Foto disimpan ke folder uploads.
- Validasi JPG/JPEG/PNG/WEBP dan maksimal 5 MB.
- Menggunakan prepared statement untuk perubahan database.

CARA MENJALANKAN
1. Ekstrak folder website-sekolah ke C:\xampp\htdocs\
2. Pastikan Apache dan MySQL aktif.
3. Pastikan database db_sekolah sudah diimpor.
4. Pastikan folder website-sekolah/uploads ada.
5. Login melalui:
   http://localhost/website-sekolah/admin/login.php
6. Buka:
   http://localhost/website-sekolah/admin/galeri.php
7. Upload foto.
8. Lihat hasilnya:
   http://localhost/website-sekolah/galeri.php

PENTING
Versi ini mengikuti struktur database yang benar-benar terdapat pada ZIP yang dikirim:
CREATE TABLE galeri (
 id INT AUTO_INCREMENT PRIMARY KEY,
 judul VARCHAR(200) NOT NULL,
 gambar VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

Tidak perlu menjalankan SQL tambahan untuk fitur galeri.
