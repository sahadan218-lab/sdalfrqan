CREATE DATABASE IF NOT EXISTS db_sekolah CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_sekolah;

CREATE TABLE pengaturan (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama_sekolah VARCHAR(200) NOT NULL,
 tagline VARCHAR(255) NOT NULL,
 alamat TEXT,
 telepon VARCHAR(50),
 email VARCHAR(150),
 visi TEXT,
 misi TEXT,
 sambutan TEXT
);
INSERT INTO pengaturan (nama_sekolah,tagline,alamat,telepon,email,visi,misi,sambutan) VALUES
('SD AL FURQAN','Mendidik dengan karakter, ilmu, dan kreativitas.','Batam, Kepulauan Riau','0778-000000','info@sekolah.sch.id','Terwujudnya peserta didik yang berkarakter, berprestasi, mandiri, dan berwawasan teknologi.','Menyelenggarakan pembelajaran yang aktif dan menyenangkan; mengembangkan karakter; meningkatkan literasi dan numerasi; memanfaatkan teknologi secara bijak.','Assalamu’alaikum warahmatullahi wabarakatuh. Selamat datang di website resmi sekolah. Semoga website ini menjadi media informasi, komunikasi, dan dokumentasi kegiatan sekolah.');

CREATE TABLE admin (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama VARCHAR(100) NOT NULL,
 username VARCHAR(50) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL
);
INSERT INTO admin(nama,username,password) VALUES
('Administrator','admin','$2y$12$sHUSf1i4KDticKE7.ofPh.xDtAXOuqepEzQ2F4ZlNm9w47L4YPjV6');

CREATE TABLE berita (
 id INT AUTO_INCREMENT PRIMARY KEY,
 judul VARCHAR(255) NOT NULL,
 isi TEXT NOT NULL,
 tanggal DATE NOT NULL,
 gambar VARCHAR(255) DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO berita(judul,isi,tanggal) VALUES
('Selamat Datang di Website Sekolah','Website sekolah resmi hadir sebagai media informasi, komunikasi, dan dokumentasi kegiatan sekolah.',CURDATE()),
('Awal Tahun Pelajaran 2026/2027','Selamat datang peserta didik pada tahun pelajaran baru. Mari belajar dengan semangat dan penuh tanggung jawab.',CURDATE());

CREATE TABLE guru (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama VARCHAR(150) NOT NULL,
 jabatan VARCHAR(100) NOT NULL,
 mapel VARCHAR(100) NOT NULL,
 foto VARCHAR(255) DEFAULT NULL
);
INSERT INTO guru(nama,jabatan,mapel) VALUES
('Nama Kepala Sekolah','Kepala Sekolah','Manajemen Sekolah'),
('Nama Guru 1','Guru Kelas','Kelas IV'),
('Nama Guru 2','Guru Mata Pelajaran','Informatika'),
('Nama Guru 3','Guru Mata Pelajaran','PJOK');

CREATE TABLE galeri (
 id INT AUTO_INCREMENT PRIMARY KEY,
 judul VARCHAR(200) NOT NULL,
 gambar VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE agenda (
 id INT AUTO_INCREMENT PRIMARY KEY,
 judul VARCHAR(200) NOT NULL,
 tanggal DATE NOT NULL,
 lokasi VARCHAR(150) NOT NULL,
 keterangan VARCHAR(255) NOT NULL
);
INSERT INTO agenda(judul,tanggal,lokasi,keterangan) VALUES
('Rapat Awal Tahun','2026-07-15','Ruang Guru','Persiapan program sekolah'),
('Kegiatan Literasi','2026-08-10','Perpustakaan','Literasi membaca peserta didik');

CREATE TABLE kegiatan (
 id INT AUTO_INCREMENT PRIMARY KEY,
 judul VARCHAR(200) NOT NULL,
 tanggal DATE NOT NULL,
 deskripsi TEXT NOT NULL
);
INSERT INTO kegiatan(judul,tanggal,deskripsi) VALUES
('Masa Pengenalan Lingkungan Sekolah','2026-07-13','Kegiatan pengenalan lingkungan dan budaya sekolah.'),
('Proyek Literasi dan Numerasi','2026-08-20','Kegiatan penguatan literasi dan numerasi melalui pembelajaran kontekstual.');

-- Username admin: admin
-- Password admin: password
