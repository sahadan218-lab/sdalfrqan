USE db_sekolah;
UPDATE admin SET password = '$2y$12$sHUSf1i4KDticKE7.ofPh.xDtAXOuqepEzQ2F4ZlNm9w47L4YPjV6' WHERE username = 'admin';
