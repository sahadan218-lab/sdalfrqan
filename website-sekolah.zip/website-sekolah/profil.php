<?php $title='Profil Sekolah'; require 'includes/header.php'; ?>
<section class="page-banner"><div class="container"><h1>Profil Sekolah</h1><p>Informasi resmi dan identitas sekolah.</p></div></section>
<section class="section"><div class="container prose">
<h2>Sambutan Kepala Sekolah</h2><p><?= nl2br(htmlspecialchars($site['sambutan'])) ?></p>
<h2>Visi</h2><p><?= nl2br(htmlspecialchars($site['visi'])) ?></p>
<h2>Misi</h2><p><?= nl2br(htmlspecialchars($site['misi'])) ?></p>
</div></section>
<?php require 'includes/footer.php'; ?>