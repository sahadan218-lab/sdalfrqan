import { db } from "hatchable";
export const access="user";
export const methods=["GET","POST"];
export default async function(req,res){
 const r=await db.query("SELECT * FROM profiles WHERE id=$1",[req.user.id]);const p=r.rows[0];
 if(!p)return res.status(404).json({error:"Profil belum tersedia"});
 if(req.method==="GET")return res.json({profile:p});
 if(p.role!=="admin")return res.status(403).json({error:"Hanya admin"});
 const {email,full_name,role,teacher_type,class_id}=req.body;
 if(!email||!["guru","siswa"].includes(role))return res.status(400).json({error:"Email dan peran valid wajib diisi"});
 await db.query("INSERT INTO invited_users(email) VALUES(lower($1)) ON CONFLICT DO NOTHING",[email]);
 return res.json({ok:true,message:"Undangan dibuat. Pengguna masuk menggunakan kode verifikasi email, lalu Admin dapat menetapkan profil dan penugasannya.",full_name,role,teacher_type,class_id});
}