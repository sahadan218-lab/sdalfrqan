import { db } from "hatchable";
export const access = "user";
export const methods = ["GET","POST","PUT","DELETE"];
const tables={classes:"classes",subjects:"subjects",teachers:"profiles",students:"students",outcomes:"curriculum_outcomes",materials:"materials",assignments:"assignments",submissions:"submissions",assessments:"assessments",announcements:"announcements",notifications:"notifications",assignments_list:"assignments",materials_list:"materials"};
const fields={classes:["name","grade","phase","homeroom_teacher"],subjects:["name","active"],outcomes:["curriculum","phase","class_id","subject_id","cp","tp","academic_year","semester"],materials:["title","description","class_id","subject_id","outcome_id","file_url","file_name","video_url","publish_at","status"],assignments:["title","instructions","class_id","subject_id","outcome_id","kind","attachment_url","due_at","points","status"],assessments:["title","kind","class_id","subject_id","outcome_id","duration_minutes","due_at","shuffle_questions","status"],announcements:["title","body","class_id","audience"],teachers:["full_name","email","role","teacher_type","active"],students:["nisn","gender","birth_place","birth_date","parent_name","parent_phone","class_id"]};
async function profile(id){const r=await db.query("SELECT * FROM profiles WHERE id=$1",[id]);return r.rows[0]||null;}
async function allowed(p,table,row){
 if(p.role==="admin")return true;
 if(p.role==="pending")return false;
 if(table==="notifications")return row.user_id===p.id;
 if(table==="submissions")return p.role==="siswa"?row.student_id===p.id:true;
 if(p.role==="siswa")return ["classes","subjects","outcomes","materials","assignments","assessments","announcements","students"].includes(table);
 if(p.role==="guru"){
  if(["classes","subjects"].includes(table))return true;
  if(row.created_by&&row.created_by!==p.id)return false;
  if(row.class_id){const a=await db.query("SELECT 1 FROM teaching_assignments WHERE teacher_id=$1 AND class_id=$2 LIMIT 1",[p.id,row.class_id]);return !!a.rows.length;}
  return true;
 }
 return false;
}
export default async function(req,res){
 const p=await profile(req.user.id); if(!p)return res.status(403).json({error:"Profil belum dibuat. Muat ulang halaman."});
 if(!p.active||p.role==="pending")return res.status(403).json({error:"Akun menunggu persetujuan administrator."});
 const action=req.body?.action||req.query?.action; const table=req.body?.table||req.query?.table;
 if(action==="dashboard"){
  const q=async(sql,params=[])=>{const r=await db.query(sql,params);return Number(r.rows[0]?.n||0)};
  if(p.role==="admin")return res.json({role:p.role,teachers:await q("SELECT count(*) n FROM profiles WHERE role='guru'"),students:await q("SELECT count(*) n FROM profiles WHERE role='siswa'"),classes:await q("SELECT count(*) n FROM classes"),subjects:await q("SELECT count(*) n FROM subjects"),materials:await q("SELECT count(*) n FROM materials"),tasks:await q("SELECT count(*) n FROM assignments"),pending:await q("SELECT count(*) n FROM profiles WHERE role='pending'")});
  if(p.role==="guru")return res.json({role:p.role,classes:await q("SELECT count(DISTINCT class_id) n FROM teaching_assignments WHERE teacher_id=$1",[p.id]),materials:await q("SELECT count(*) n FROM materials WHERE created_by=$1",[p.id]),tasks:await q("SELECT count(*) n FROM assignments WHERE created_by=$1",[p.id]),ungraded:await q("SELECT count(*) n FROM submissions s JOIN assignments a ON a.id=s.assignment_id WHERE a.created_by=$1 AND s.graded=false",[p.id])});
  return res.json({role:p.role,materials:await q("SELECT count(*) n FROM materials m JOIN students s ON s.class_id=m.class_id WHERE s.profile_id=$1 AND m.status='published'",[p.id]),tasks:await q("SELECT count(*) n FROM assignments a JOIN students s ON s.class_id=a.class_id WHERE s.profile_id=$1 AND a.status='published'",[p.id]),notifications:await q("SELECT count(*) n FROM notifications WHERE user_id=$1 AND read_at IS NULL",[p.id])});
 }
 if(action==="me")return res.json({profile:p});
 if(action==="list"){
  if(!tables[table])return res.status(400).json({error:"Modul tidak dikenal"});
  let sql="SELECT * FROM "+tables[table]+" ORDER BY created_at DESC NULLS LAST LIMIT 300";
  if(table==="teachers")sql="SELECT * FROM profiles WHERE role IN ('guru','admin','pending') ORDER BY created_at DESC LIMIT 300";
  if(table==="students")sql="SELECT s.*,p.full_name,p.email,p.active,c.name AS class_name FROM students s JOIN profiles p ON p.id=s.profile_id LEFT JOIN classes c ON c.id=s.class_id ORDER BY p.full_name LIMIT 500";
  if(table==="submissions"&&p.role==="guru")sql="SELECT s.*,p.full_name,a.title AS assignment_title FROM submissions s JOIN profiles p ON p.id=s.student_id JOIN assignments a ON a.id=s.assignment_id WHERE a.created_by=$1 ORDER BY s.submitted_at DESC";
  if(table==="submissions"&&p.role==="siswa")sql="SELECT s.*,a.title AS assignment_title FROM submissions s JOIN assignments a ON a.id=s.assignment_id WHERE s.student_id=$1 ORDER BY s.submitted_at DESC";
  if(table==="materials"&&p.role==="siswa")sql="SELECT * FROM materials WHERE status='published' AND class_id=(SELECT class_id FROM students WHERE profile_id=$1) ORDER BY created_at DESC";
  if(table==="assignments"&&p.role==="siswa")sql="SELECT * FROM assignments WHERE status='published' AND class_id=(SELECT class_id FROM students WHERE profile_id=$1) ORDER BY due_at";
  const r=await db.query(sql,p.role==="siswa"||table==="submissions"&&p.role==="guru"?[p.id]:[]);
  const rows=[];for(const x of r.rows)if(await allowed(p,table,x))rows.push(x);
  return res.json({rows,profile:p});
 }
 if(action==="save"&&(req.method==="POST"||req.method==="PUT")){
  if(!fields[table])return res.status(400).json({error:"Modul tidak dapat diubah"});
  if(p.role==="siswa")return res.status(403).json({error:"Tidak memiliki izin"});
  const b=req.body.data||{};const keys=fields[table].filter(k=>b[k]!==undefined);
  if(!keys.length)return res.status(400).json({error:"Isi data terlebih dahulu"});
  if(p.role==="guru"&&!["materials","assignments","assessments","announcements","submissions","outcomes"].includes(table))return res.status(403).json({error:"Guru tidak dapat mengubah modul ini"});
  if(table==="teachers"&&p.role!=="admin")return res.status(403).json({error:"Hanya admin"});
  if(table==="materials"||table==="assignments"||table==="assessments"){
   if(!b.class_id||!b.subject_id||!b.outcome_id)return res.status(400).json({error:"Pilih kelas, mata pelajaran, CP, dan TP terlebih dahulu"});
   if(p.role==="guru"){const a=await db.query("SELECT 1 FROM teaching_assignments WHERE teacher_id=$1 AND class_id=$2 AND subject_id=$3 LIMIT 1",[p.id,b.class_id,b.subject_id]);if(!a.rows.length)return res.status(403).json({error:"Kelas/mapel bukan penugasan Anda"});}
  }
  if(table==="outcomes"&&p.role==="guru")return res.status(403).json({error:"CP/TP dikelola Admin"});
  let result;
  if(req.body.id){
   const sets=keys.map((k,i)=>k+"=$"+(i+1)).join(",");
   const vals=keys.map(k=>b[k]);vals.push(req.body.id);
   result=await db.query("UPDATE "+tables[table]+" SET "+sets+" WHERE id=$"+vals.length+" RETURNING *",vals);
  }else{
   const data={...b};if(["materials","assignments","assessments","announcements"].includes(table))data.created_by=p.id;
   if(table==="teachers"&&p.role==="admin")return res.status(400).json({error:"Akun guru dibuat melalui menu Undangan akun; guru perlu masuk dengan email sekolah."});
   if(table==="students"&&p.role==="admin")return res.status(400).json({error:"Buat profil siswa setelah akun email siswa terdaftar."});
   const k=keys.filter(x=>data[x]!==undefined);if(data.created_by)k.push("created_by");
   result=await db.query("INSERT INTO "+tables[table]+" ("+k.join(",")+") VALUES ("+k.map((_,i)=>"$"+(i+1)).join(",")+") RETURNING *",k.map(x=>data[x]));
  }
  await db.query("INSERT INTO activity_logs(user_id,action,entity,entity_id) VALUES($1,$2,$3,$4)",[p.id,req.body.id?"Memperbarui":"Menambahkan",table,result.rows[0]?.id||null]);
  return res.json({row:result.rows[0]});
 }
 if(action==="delete"&&req.method==="DELETE"){
  if(p.role!=="admin")return res.status(403).json({error:"Hanya admin yang dapat menghapus data master"});
  if(!tables[table])return res.status(400).json({error:"Modul tidak dikenal"});
  await db.query("DELETE FROM "+tables[table]+" WHERE id=$1",[req.body.id]);return res.json({ok:true});
 }
 if(action==="publish"&&req.method==="POST"){
  const t=table==="materials"?"materials":table==="assignments"?"assignments":table==="assessments"?"assessments":null;if(!t)return res.status(400).json({error:"Modul tidak valid"});
  await db.query("UPDATE "+t+" SET status='published' WHERE id=$1 AND created_by=$2",[req.body.id,p.id]);return res.json({ok:true});
 }
 if(action==="submit"&&req.method==="POST"&&p.role==="siswa"){
  const a=await db.query("SELECT id FROM assignments WHERE id=$1 AND status='published' AND class_id=(SELECT class_id FROM students WHERE profile_id=$2)",[req.body.assignment_id,p.id]);if(!a.rows.length)return res.status(404).json({error:"Tugas tidak ditemukan"});
  const r=await db.query("INSERT INTO submissions(assignment_id,student_id,answer,file_url,file_name,submitted_at) VALUES($1,$2,$3,$4,$5,now()) ON CONFLICT(assignment_id,student_id) DO UPDATE SET answer=EXCLUDED.answer,file_url=EXCLUDED.file_url,file_name=EXCLUDED.file_name,submitted_at=now() RETURNING *",[req.body.assignment_id,p.id,req.body.answer||"",req.body.file_url||null,req.body.file_name||null]);return res.json({row:r.rows[0]});
 }
 if(action==="grade"&&req.method==="POST"&&p.role!=="siswa"){
  const r=await db.query("UPDATE submissions SET score=$1,feedback=$2,graded=true,published=$3 WHERE id=$4 RETURNING *",[req.body.score,req.body.feedback||"",!!req.body.published,req.body.id]);if(r.rows[0])await db.query("INSERT INTO notifications(user_id,title,body) VALUES($1,'Hasil penilaian tersedia',$2)",[r.rows[0].student_id,"Tugas Anda telah dinilai."]);return res.json({row:r.rows[0]});
 }
 return res.status(400).json({error:"Aksi tidak tersedia"});
}