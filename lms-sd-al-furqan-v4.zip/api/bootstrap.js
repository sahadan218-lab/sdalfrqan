import { db, auth } from "hatchable";
export const access = "user";
export const methods = ["GET","POST"];
export default async function(req,res){
 const u=req.user;
 const found=await db.query("SELECT * FROM profiles WHERE id=$1",[u.id]);
 if(found.rows.length) return res.json({profile:found.rows[0]});
 const n=await db.query("SELECT count(*)::int AS n FROM profiles");
 const role=n.rows[0].n===0?"admin":"pending";
 const name=(req.body?.name||u.name||u.email.split("@")[0]).toString().slice(0,120);
 const made=await db.query("INSERT INTO profiles(id,email,full_name,role) VALUES($1,lower($2),$3,$4) RETURNING *",[u.id,u.email,name,role]);
 await db.query("INSERT INTO activity_logs(user_id,action,entity) VALUES($1,'Mendaftar','akun')",[u.id]);
 res.json({profile:made.rows[0],first_admin:role==="admin"});
}