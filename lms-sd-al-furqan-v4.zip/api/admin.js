import { db } from "hatchable";
export const access="user";
export const methods=["GET","POST","DELETE"];
export default async function(req,res){
 const me=await db.query("SELECT * FROM profiles WHERE id=$1",[req.user.id]);
 if(me.rows[0]?.role!=="admin")return res.status(403).json({error:"Khusus administrator"});
 if(req.method==="GET"){
  const users=await db.query("SELECT p.id,p.email,p.full_name,p.role,p.teacher_type,p.active,s.nisn,s.class_id,c.name AS class_name FROM profiles p LEFT JOIN students s ON s.profile_id=p.id LEFT JOIN classes c ON c.id=s.class_id ORDER BY p.created_at DESC");
  const assignments=await db.query("SELECT a.*,p.full_name,c.name AS class_name,s.name AS subject_name FROM teaching_assignments a JOIN profiles p ON p.id=a.teacher_id JOIN classes c ON c.id=a.class_id JOIN subjects s ON s.id=a.subject_id ORDER BY p.full_name");
  return res.json({users:users.rows,assignments:assignments.rows});
 }
 if(req.method==="POST"){
  const b=req.body;
  if(b.action==="invite"){
   if(!b.email)return res.status(400).json({error:"Email wajib diisi"});
   return res.json({ok:true,message:"Pengguna dapat mendaftar menggunakan email sekolah melalui halaman masuk. Setelah login pertama, Admin menetapkan peran dan kelas."});
  }
  if(b.action==="role"){
   if(!["guru","siswa","admin","pending"].includes(b.role))return res.status(400).json({error:"Peran tidak valid"});
   await db.query("UPDATE profiles SET role=$1,full_name=COALESCE(NULLIF($2,''),full_name),teacher_type=$3,active=$4 WHERE id=$5",[b.role,b.full_name||"",b.teacher_type||null,b.active!==false,b.user_id]);
   if(b.role==="siswa"){
    await db.query("INSERT INTO students(profile_id,nisn,class_id) VALUES($1,$2,$3) ON CONFLICT(profile_id) DO UPDATE SET nisn=EXCLUDED.nisn,class_id=EXCLUDED.class_id",[b.user_id,b.nisn||null,b.class_id||null]);
   }
   await db.query("INSERT INTO activity_logs(user_id,action,entity,entity_id) VALUES($1,'Mengubah peran akun','profiles',$2)",[req.user.id,b.user_id]);
   return res.json({ok:true});
  }
  if(b.action==="assignment"){
   await db.query("INSERT INTO teaching_assignments(teacher_id,class_id,subject_id,academic_year,semester) VALUES($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING",[b.teacher_id,b.class_id,b.subject_id,b.academic_year||"2026/2027",b.semester||"Ganjil"]);
   return res.json({ok:true});
  }
  if(b.action==="announcement"){
   await db.query("INSERT INTO announcements(title,body,audience,created_by) VALUES($1,$2,'all',$3)",[b.title,b.body,req.user.id]);return res.json({ok:true});
  }
 }
 if(req.method==="DELETE"){
  if(req.body.action==="assignment")await db.query("DELETE FROM teaching_assignments WHERE id=$1",[req.body.id]);
  else await db.query("UPDATE profiles SET active=false WHERE id=$1",[req.body.user_id]);
  return res.json({ok:true});
 }
 return res.status(400).json({error:"Aksi tidak dikenal"});
}